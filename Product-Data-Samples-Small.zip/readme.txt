listofproducts.json - here you have a list of data samples 
SAN2TWPT290.json - here you get some details by article number
SAN2EDPT9090.json
SAN2TWFT70.json
SAN2EDPT8080,json
SAN2PTNFS100.json
SAN2A23380.json